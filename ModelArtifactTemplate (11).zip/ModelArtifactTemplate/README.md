# Model Artifact Boilerplate Code

This zip archive contains boilerplate code to generate a model artifact.

The artifact should minimally contain the following files:
- score.py
- runtime.yaml

Follow the steps below to successfully create a model artifact.

## Step 1. Save Your Model Object

You can use a variety of tools to save your model (joblib, cloudpickle, pickle, onnx, etc). We recommend that you save your model 
object in the top level directory of your model artifact, at the same level as `score.py` and `runtime.yaml`. 

## Step 2. Modify `score.py`

Two functions are defined in score.py: `load_model()` and `predict()`. You will need to customize the body of the both functions to support your model. 

* `load_model()` reads the model file on disk and returns the estimator object. When modifying `load_model()`, **make sure that you use the same library for serializing 
and de-serializing the model object**. 

* `predict()` has two parameters: `data` and `model`. The required parameter is `data` which represents a dataset payload while `model` is an optional parameter. 
  By default `model` is the object returned by `load_model()`. Ensure that the data type of the `data` parameter matches the payload format you expect with model deployment.
  By default, Model Deployment assumes that `data` is a JSON payload (application/json). The `predict()` function should be able to convert the JSON payload into, for example,  a Pandas Dataframe or a Numpy array 
  if that is the data format supported by the the model object. In addition, the body of predict() can include data transformations and other data manipulation tasks before a model prediction is made.

A few additional things to keep in mind: 

* The function signatures of `load_model()` and `predict()`, are not editable. Only the body of these functions is customizable.

* any custom Python modules can be imported in score.py if they are available in the artifact file or as part of the conda environment used for inference purposes. 

* You can save more than one model object in your artifact and load more than one estimator object to memory to perform an ensemble evaluation. 
  In this case, `load_model()` could return an array of model objects that are processed by `predict()`


## (OPTIONAL) Step 3. Test the score.predict() Function

We recommend that you test the `predict()` function in your local environment before saving the model to the catalog. The code snippet below 
showcases how you can pass a json payload to predict that would mimic the behavior of your model as deployed through Model Deployment. This is a good 
way to check that the model object is read by `load_model()` and that the predictions returned by your models are correct and in the format you expect. 

```
import sys
from json import dumps

# The local path to your model artifact directory is added to the Python path.
# replace <your-model-artifact-path>
sys.path.insert(0, f"<your-model-artifact-path>")

# importing load_model() and predict() that are defined in score.py
from score import load_model, predict

# Loading the model to memory
_ = load_model()
# Making predictions on a JSON string object (dumps(data)). Here we assume
# that predict() is taking data in JSON format
predictions_test = predict(dumps(data), _)
predictions_test
```

## Step 4. Modify runtime.yaml

Next, modify the runtime.yaml file. This file provides a reference to the conda environment you want to use for the runtime environment for Model Deployment.
Minimally `runtime.yaml` should contain the following fields:

```
MODEL_ARTIFACT_VERSION: '3.0'
MODEL_DEPLOYMENT:
  INFERENCE_CONDA_ENV:
    INFERENCE_ENV_SLUG: <insert-the-environment-slug> # for example mlcpuv1 see: https://docs.oracle.com/en-us/iaas/data-science/using/conda-gml-fam.htm
    INFERENCE_ENV_TYPE: <env-type> # can either be "published" or "data_science"
    INFERENCE_ENV_PATH: <conda-environment-path-on-object-storage> # For example: 
    INFERENCE_PYTHON_VERSION: '3.7' #
```

Go to this page(link to https://docs.oracle.com/en-us/iaas/data-science/using/model_runtime_yaml.htm) for a definition of all the parameters that can be included in `runtime.yaml`.  

As an example, here's a complete `runtime.yaml` for a data_science conda environment (mlcpuv1) used as a runtime environment for model deployment. 
In most cases the runtime environment for model deployment should be the same as the conda environment used to train the model. 

```
MODEL_ARTIFACT_VERSION: '3.0'
MODEL_DEPLOYMENT:
  INFERENCE_CONDA_ENV:
    INFERENCE_ENV_PATH: oci://service-conda-packs@id19sfcrra6z/service_pack/cpu/General
      Machine Learning for CPUs/1.0/mlcpuv1
    INFERENCE_ENV_SLUG: mlcpuv1
    INFERENCE_ENV_TYPE: data_science
    INFERENCE_PYTHON_VERSION: 3.6.11
```

## (OPTIONAL) Step 5. Provide Model Input and Output Data Schema

Next, you can optionally include a data schema definition for both the input feature vector of your model as well as a schema describing the predictions returned by your model.
It is possible to add these schemas after the model has been saved to the catalog.

**I NEED HELP FROM TEAM HERE** 

## (OPTIONAL) Step 6. Run Model Artifact Introspection Tests

Next, run a series of introspection tests on your model artifact before saving the model to the model catalog. The purpose of these tests is to capture many of the 
common model artifact errors before the model is saved to the model catalog. Introspection tests check `score.py` for syntax errors, verify the signature of 
functions `load_model()` and `predict()`, and validate the content of `runtime.yaml`. The introspection tests are found in `model-artifact-validation/model_artifact_validate.py`.


### Installation

Python version > 3.5 is required to run the tests. Before running the tests locally on your machine, two Python libraries need to be installed 
namely `pyyaml` and `requests`. This installation step is a one-time operation. Go to your artifact directory and run the following command: 

```
python3 -m pip install --user -r model-artifact-validation/requirements.txt
```

### Running the Tests Locally

Next, replace `<artifact-path>` with the path to your model artifact directory
```
python3 model-artifact-validation/model_artifact_validate.py --artifact <artifact-path>
```

The script automatically generates a report of the test results in the same folder . Three files are generated containing the test results in different formats:  
* `test_csv_output.csv`
* `test_json_output.json`
* `test_html_output.html`

Repeat Steps 1-6 until no error is found. 


## Step 7. Save your model to the catalog

You are now ready to save the model to the catalog. First zip your artifact directory and use either the OCI SDK or CLI to save your model artifact to the model catalog 

**I NEED HELP FROM TEAM HERE** 



---

# Appendix

## Artifact introspection tests

* Check that the files 'score.py' and 'runtime.yaml' exists and is in the top level directory of the artifact directory

* In score.py:
    * Check for Python syntax errors
    * Check that a function called load_model() is defined
    * Check that a function called predict() is defined
    * Check that the only required argument for predict() is named `data`
    * Check that all other arguments in predict() are optional and have default values

* In runtime.yaml:
    * Check that field MODEL_ARTIFACT_VERSION is set to 3.0
    * Check that field MODEL_DEPLOYMENT.INFERENCE_ENV_TYPE is set to a value in (published, data_science)
    * Check that field MODEL_DEPLOYMENT.INFERENCE_ENV_SLUG is set
    * Check that field MODEL_DEPLOYMENT.INFERENCE_ENV_PATH is set
    * If MODEL_DEPLOYMENT.INFERENCE_ENV_TYPE is data_science, check that the slug listed in MODEL_DEPLOYMENT.INFERENCE_ENV_SLUG exists.
    * If MODEL_DEPLOYMENT.INFERENCE_ENV_TYPE is data_science and MODEL_DEPLOYMENT.INFERENCE_ENV_SLUG exists, check that the file path in MODEL_DEPLOYMENT.INFERENCE_ENV_PATH is correct.
    * If MODEL_DEPLOYMENT.INFERENCE_ENV_TYPE is published, check that the file path in MODEL_DEPLOYMENT.INFERENCE_ENV_PATH exists.
    * Add a warning if MODEL_DEPLOYMENT.INFERENCE_ENV_TYPE is published to let the user know that they need to write the correct access policy to let model deployment read from their object storage bucket.