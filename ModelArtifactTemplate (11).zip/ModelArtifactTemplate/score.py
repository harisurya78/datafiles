import json
import os

from functools import lru_cache
from transformers import AutoTokenizer, AutoModelForSequenceClassification

model_name = "pytorch_model.bin"
tokenize_name = 'vocab'

@lru_cache(maxsize=10)
def load_model(model_file_name=model_name):
    """
    Loads model from the serialized format

    Returns
    -------
    model:  a model instance on which predict API can be invoked
    """
    model_dir = os.path.dirname(os.path.realpath(__file__))
    contents = os.listdir(model_dir)
    if model_file_name in contents:
        model = AutoModelForSequenceClassification.from_pretrained(model_dir)
        return model
    else:
        raise Exception('{0} is not found in model directory {1}'.format(model_file_name, model_dir))


def predict(data, model=load_model()):
    """
    Returns prediction given the model and data to predict

    Parameters
    ----------
    model: Model instance returned by load_model API
    data: Data format as expected by the predict API of the core estimator. For eg. in case of sckit models it could be numpy array/List of list/Panda DataFrame

    Returns
    -------
    predictions: Output from scoring server
        Format: {'prediction':output from model.predict method}

    """
    tokenizer_dir = os.path.dirname(os.path.realpath(__file__))
    contents = os.listdir(tokenizer_dir)
    LABELS = ["negative", "positive"]    
    if tokenize_name + '.json' in contents:
        tokenizer = AutoTokenizer.from_pretrained(tokenizer_dir)
    outputs = []
    for text in data:
        inputs = tokenizer.encode_plus(text, return_tensors='pt')
        output = model(**inputs)[0].squeeze().detach().numpy()
        outputs.append(LABELS[(output.argmax())])
    return {'prediction': outputs}