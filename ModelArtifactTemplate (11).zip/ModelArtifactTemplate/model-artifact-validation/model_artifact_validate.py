#!/usr/bin/env python3

import argparse
import ast
import csv
import json
import logging
import os
import shutil
import sys
import tempfile
import zipfile
from typing import Tuple
import re

import requests
import yaml

logger = logging.getLogger()
logging.basicConfig(level=logging.DEBUG)


_cwd = os.path.dirname(__file__)

TESTS_PATH = os.path.join(_cwd, '.resources', 'tests.yaml')
HTML_PATH = os.path.join(_cwd, '.resources', 'template.html')
CONFIG_PATH = os.path.join(_cwd, '.resources', 'config.yaml')

PYTHON_VER_PATTERN = "^([3])(\.[6-9])(\.\d+)?$"

with open(CONFIG_PATH, 'r') as ymlfile:
    config_dict = yaml.load(ymlfile, Loader=yaml.FullLoader)
PAR_URL = config_dict['PAR_URL']

logger.info(f'TEST PATH : {TESTS_PATH}')

with open(TESTS_PATH, 'r') as ymlfile:
    TESTS = yaml.load(ymlfile, Loader=yaml.FullLoader)


def combine_msgs(test_list) -> str:
    '''
    For a given test_list combine all error_msg if test failed
    '''
    msgs = [TESTS[test]['error_msg'] for test in test_list if not TESTS[test].get('success')]
    return '\n'.join(msgs)



def model_deployment_find_fields(cfg) -> None:
    '''
    Recursively checks in MODEL_DEPLOYMENT if INFERENCE_ENV_SLUG, INFERENCE_ENV_TYPE, INFERENCE_ENV_PATH
    Also saves its value if present.
    '''
    if not isinstance(cfg, dict):
        return
    for key, value in cfg.items():
        if key == 'INFERENCE_ENV_SLUG':
            TESTS['runtime_env_slug']['success'] = True
            TESTS['runtime_env_slug']['value'] = value
        elif key == 'INFERENCE_ENV_TYPE':
            if value in ['published', 'data_science']:
                TESTS['runtime_env_type']['success'] = True
                TESTS['runtime_env_type']['value'] = value
        elif key == 'INFERENCE_ENV_PATH':
            TESTS['runtime_env_path']['success'] = True
            TESTS['runtime_env_path']['value'] = value
        elif key == 'INFERENCE_PYTHON_VERSION':
            TESTS['runtime_env_python']['success'] = True
            TESTS['runtime_env_python']['value'] = value
        else:
            model_deployment_find_fields(value)


def check_runtime_yml(file_path) -> Tuple[bool, str]:
    '''
    Check runtime yaml mandatory fields
    '''

    with open(file_path, 'r') as ymlfile:
        cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)

    logger.info('Validating YAML')
    if not isinstance(cfg, dict):
        return False, 'runtime.yaml is not valid.'

    model_arti_ver = cfg.get('MODEL_ARTIFACT_VERSION')  # if not present None
    if model_arti_ver == '3.0':
        TESTS['runtime_version']['success'] = True
        logger.info('runtime.yaml version is correct')
    else:
        logger.debug(f'MODEL_ARTIFACT_VERSION: {model_arti_ver}')
        TESTS['runtime_version']['success'] = False
        return False, TESTS['runtime_version']['error_msg']

    model_deployment = cfg.get('MODEL_DEPLOYMENT')
    model_deployment_find_fields(model_deployment)
    test_list = ['runtime_env_python','runtime_env_type', 'runtime_env_path', 'runtime_env_slug']
    for test in test_list:
        if 'success' not in TESTS[test]:
            TESTS[test]['success'] = False
    msg = combine_msgs(test_list)
    if msg:
        return False, msg
    try:
        m = re.match(PYTHON_VER_PATTERN, str(TESTS['runtime_env_python']['value']))
        if m and m.group():
            TESTS['runtime_env_python']['success']  = True        
            response = requests.request('GET', PAR_URL)
            logger.debug(f'PAR response: {response}')
            if response.ok:
                service_pack_list = response.json().get('service_packs')
                env_path = TESTS['runtime_env_path']['value']
                service_pack = next(filter(lambda d: d['pack_path'] == env_path, service_pack_list), None)
                if service_pack:
                    TESTS['runtime_path_exist']['success'] = True
                    if TESTS['runtime_env_type']['value'] == 'data_science':
                        logger.info('Checking slug as runtime_env_type is data science.')
                        slug = service_pack.get('slug')
                        if slug == TESTS['runtime_env_slug'].get('value'):
                            TESTS['runtime_slug_exist']['success'] = True
                            return True, 'slug is valid'
                        else:
                            logger.error(f'Mismatch in slug {slug}.')
                            TESTS['runtime_slug_exist']['success'] = False
                            return False, TESTS['runtime_slug_exist']['error_msg']
                    else:
                            return False, 'WARNING: Provide the correct access policy as INFERENCE_ENV_TYPE is published'
                else:
                    TESTS['runtime_path_exist']['success'] = False
                    return False, TESTS['runtime_path_exist']['error_msg']
            else:
                    TESTS['runtime_path_exist']['success'] = False
                    return False, TESTS['runtime_path_exist']['error_msg']
        else:
            logger.error(f'Mismatch in python version')
            TESTS['runtime_env_python']['success']  = False
            return False, TESTS['runtime_env_python']['error_msg'] 
                    
    except Exception as e:
        return False, str(e)
            
            
def check_score_file(file_path) -> Tuple[bool, str]:
    '''
    Change current working directory to temporary direcory and validate python file
    '''
    with open(file_path) as f:
        source = f.read()
    try:
        ast_module = ast.parse(source)

        TESTS['score_syntax']['success'] = True  # passed syntax check

        present_functions = {}
        for node in ast_module.body:
            if isinstance(node, ast.FunctionDef):
                present_functions[node.name] = {
                    'args': node.args.args,
                    'defaults': node.args.defaults
                }
        logger.debug(f'Functions in score.py: {present_functions}')

        TESTS['score_predict']['success'] = 'predict' in present_functions
        TESTS['score_load_model']['success'] = 'load_model' in present_functions

        msg = combine_msgs(['score_predict', 'score_load_model'])
        if msg:
            return False, msg

        logger.info('All mandodory functions are present in score.py.')

        # check if predict function take required argument 'data' and all others are optional with default values
        predict_fn = present_functions['predict']
        if predict_fn['args'][0].arg == 'data':
            TESTS['score_predict_data']['success'] = True
            logger.info('predict function in score.py have mandatory argument "data".')
            if len(predict_fn['defaults']) == len(predict_fn['args']) - 1:
                TESTS['score_predict_arg']['success'] = True
                logger.info('predict function in score.py have default values for other arguments')
                return True, 'score.py is valid.'
            else:
                TESTS['score_predict_arg']['success'] = False
                return False, TESTS['score_predict_arg']['error_msg']
        else:
            TESTS['score_predict_data']['success'] = False
            return False, TESTS['score_predict_data']['error_msg']

    except SyntaxError as e:
        TESTS['score_syntax']['success'] = False
        return False, TESTS['score_syntax']['error_msg'] + str(e) # error message has ": " e has syntax error details 


def check_mandatory_files(files_present) -> Tuple[bool, str]:
    '''
    Check if score.py and runtime.yaml are present or not.
    '''

    logger.debug(f'Files present: {files_present}')
    filename_list = [os.path.basename(fileName)for fileName in  files_present]
    TESTS['score_py']['success'] = 'score.py' in filename_list
    TESTS['runtime_yaml']['success'] = 'runtime.yaml' in filename_list

    msg = combine_msgs(['score_py', 'runtime_yaml'])
    if msg:
        return False, msg
    else:
        return True, 'All mandatory files are present.'
        

def validate_artifact(artifact) -> Tuple[bool, str]:
    '''
    Unzip the artifact zip file passed. Check for test cases. 
    The method returns the status of check and error message if any.
    :artifact: str
    '''

    output_msg = 'Validation Passed.'
    success = True
    # create temporary folder and unzip model artifact
    temp_path=''
    try:
        if artifact.endswith('.zip'):
            temp_path = tempfile.mkdtemp(dir='.')
            logger.debug(f'Temperory folder {temp_path} created.')
            with zipfile.ZipFile(artifact) as zip_ref:

                files_present = zip_ref.namelist()
                _status, _msg = check_mandatory_files(files_present)
                if not _status:
                    raise Exception(_msg)
                for file_name in files_present:
                    folder_list = file_name.split('/')
                    if len(folder_list) <= 2:
                        base_file_name = folder_list[-1]
                        if os.path.basename(base_file_name ) in ['score.py', 'runtime.yaml']:
                            source = zip_ref.open(file_name)
                            target = open(os.path.join(temp_path, os.path.basename(file_name)), "wb")
                            with source, target:
                                shutil.copyfileobj(source, target)
        elif os.path.isdir(artifact):
            files_present = os.listdir(artifact)
            _status, _msg = check_mandatory_files(files_present)
            print(files_present)
            if not _status:
                raise Exception(_msg)
        else:
            raise Exception("Invalid Artifact Path")
        if temp_path:
            dir_path = temp_path
        else:
            dir_path = artifact

        _status, _msg = check_score_file(os.path.join(dir_path, 'score.py'))
        if not _status:
            raise Exception(_msg)

        _status, _msg = check_runtime_yml(os.path.join(dir_path, 'runtime.yaml'))
        if not _status:
            raise Exception(_msg)
    except Exception as e:
        output_msg = str(e)
        success = False
    finally:
        if temp_path:
            shutil.rmtree(temp_path)
    return success, output_msg


RESULT_LIST = [True, False, None]
def get_test_result(test_id) -> int:
    '''
    Gives a number based on test result:
    0: test was success
    1: test failed
    2: didn't run test
    '''
    success = TESTS[test_id].get('success')
    return RESULT_LIST.index(success)


def write_html(output_path, output_msg) -> None:
    '''
    writes an html file to output_path based on TESTS
    '''
    logger.debug(f'Tests: {TESTS}')
    css_classes = ['pass', 'fail', 'no-test']
    category = ''
    html_response = ''
    for key, value in TESTS.items():
        if value['category'] != category:
            if category != '':
                html_response += '</ol>'
            category = value['category']
            html_response += f'<h3>{category}</h3><ol>'
        _class = css_classes[get_test_result(key)]
        html_response += f'<li class="{_class}">{TESTS[key]["description"]}</li>'
    html_response += '</ol>'
    logger.debug(f'HTML_RESPONSE: {html_response}')
    with open(HTML_PATH, 'r') as href:
        html_template = href.read()
        with open(output_path, 'w') as f:
            f.write(html_template % (output_msg, html_response))


def write_csv(output_path,output_msg) -> None:
    '''
    writes a csv file to output_path based on TESTS
    '''
    logger.debug(f'Tests: {TESTS}')
    logger.info('Writing the test status to csv')
    result_text = ['Passed', 'Failed', 'Not tested']
    with open(output_path, 'w') as f:
        w = csv.writer(f)
        w.writerow(['CATEGORY', 'DESCRIPTION', 'RESULT','ERROR/WARNING'])
        for k, v in TESTS.items():
            _result = result_text[get_test_result(k)]
            if _result == 'Not tested' and output_msg.startswith('WARNING'):
                w.writerow([v['category'], v['description'], _result,output_msg])
            elif _result == 'Failed':
                w.writerow([v['category'], v['description'], _result,output_msg])
            else:
                w.writerow([v['category'], v['description'], _result,''])
        

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Model Artifact Validation')
    required_args = parser.add_argument_group('required arguments:')
    required_args.add_argument('--artifact', required=True, help='Enter path of model artifact zip file.')

    args = parser.parse_args()
    logger.debug(f'Artifact file path {args.artifact}')
    success, output_msg = validate_artifact(args.artifact)

    # Output Files
    CSV_OUTPUT = 'test_csv_output.csv'
    HTML_OUTPUT = 'test_html_output.html'
    JSON_OUTPUT = 'test_json_output.json'
    
    logger.info('Output files are available in the same folder as {CSV_OUTPUT} {JSON_OUTPUT} and {HTML_OUTPUT}')
    
    write_html(HTML_OUTPUT, output_msg)
    write_csv(CSV_OUTPUT,output_msg)
    with open(JSON_OUTPUT, "w") as f:
        TESTS['Final_message'] = output_msg
        json.dump(TESTS, f, indent = 4)
